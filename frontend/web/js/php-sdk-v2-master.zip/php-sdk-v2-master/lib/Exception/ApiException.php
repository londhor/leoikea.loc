<?php

namespace Cloudipsp\Exception;


class ApiException extends MainException
{

}