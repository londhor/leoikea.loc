<?php

namespace Cloudipsp\Exception;


class HttpClientException extends MainException
{

}